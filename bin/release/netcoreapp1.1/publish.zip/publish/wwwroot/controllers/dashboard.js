(function(){
app.controller("dashboardCtrl", function($scope) {
    $scope.firstName = "John";
    $scope.lastName = "Doe";
   });

});
