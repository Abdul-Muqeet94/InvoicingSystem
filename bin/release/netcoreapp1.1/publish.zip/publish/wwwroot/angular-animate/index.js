require('./angular-animate');
module.exports = 'ngAnimate';
